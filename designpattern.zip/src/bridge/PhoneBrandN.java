package bridge;

/**
 * 桥接模式(Bridge)
 * 手机品牌N
 */
public class PhoneBrandN extends PhoneBrand {

    @Override
    public void run() {
        soft.run();
    }

}

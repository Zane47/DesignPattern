package proxy;

/**
 * 代理模式(Proxy)
 * 代理接口
 */
public interface GiveGift {

    void giveDolls();

    void giveFlowers();

    void giveChocolate();

}

package abstractfactory;

/**
 * 抽象工厂方法(Abstract Factory)
 * 部门实体类
 */
public class Department {
    // ...
}

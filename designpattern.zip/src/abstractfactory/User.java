package abstractfactory;

/**
 * 抽象工厂方法(Abstract Factory)
 * 用户实体类
 */
public class User {
    // ...
}

package bridge;

/**
 * 桥接模式(Bridge)
 * 手机品牌M
 */
public class PhoneBrandM extends PhoneBrand {

    @Override
    public void run() {
        soft.run();
    }

}

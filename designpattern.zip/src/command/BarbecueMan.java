package command;

/**
 * 命令模式(Command)
 * 烤肉串者
 */
public class BarbecueMan {

    // 烤羊肉
    public void bakeMutton() {
        System.out.println("烤羊肉");
    }

    // 烤鸡翅
    public void bakeChickenWing() {
        System.out.println("烤鸡翅");
    }

}
